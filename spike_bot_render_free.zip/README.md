# Spike Detection Bot (Free Version)

This is a basic setup to deploy a spike detection trading bot to Render.com using a free plan.

## Includes
- Flask server
- `render.yaml` for Render deployment
- `requirements.txt`